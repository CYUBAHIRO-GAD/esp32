#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <HTTPClient.h>

// ====== EDIT THESE ======
const char* WIFI_SSID = "YOUR_WIFI_NAME";
const char* WIFI_PASS = "YOUR_WIFI_PASSWORD";
// Your online server address, no slash at the end
const char* SERVER = "https://your-app.onrender.com";
const char* DEVICE_ID = "esp32-1";
const char* DEVICE_KEY = "change-me-123";   // same as DEVICE_KEY on the server
const int LED_PIN = 2;                       // built-in LED on most ESP32 boards
// ========================

void connectWifi() {
  WiFi.begin(WIFI_SSID, WIFI_PASS);
  Serial.print("Connecting");
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("\nConnected: " + WiFi.localIP().toString());
}

void setup() {
  Serial.begin(115200);
  pinMode(LED_PIN, OUTPUT);
  connectWifi();
}

void loop() {
  if (WiFi.status() != WL_CONNECTED) {
    connectWifi();
  }

  WiFiClientSecure client;
  client.setInsecure();   // skips certificate check: fine for testing, see README

  HTTPClient http;
  String url = String(SERVER) + "/api/esp/" + DEVICE_ID + "?key=" + DEVICE_KEY;
  if (http.begin(client, url)) {
    http.setTimeout(8000);
    int code = http.GET();
    if (code == 200) {
      String cmd = http.getString();
      cmd.trim();
      digitalWrite(LED_PIN, cmd == "ON" ? HIGH : LOW);
      Serial.println("Command: " + cmd);
    } else {
      Serial.println("HTTP error: " + String(code));
    }
    http.end();
  }
  delay(3000);   // ask every 3 seconds
}
